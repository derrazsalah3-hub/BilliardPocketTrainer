package com.example.billiardtrainer;
import android.app.*; import android.os.*; import android.content.*; import android.net.*; import android.provider.Settings; import android.graphics.Color; import android.widget.*;

public class MainActivity extends Activity {
 public void onCreate(Bundle b){
  super.onCreate(b);
  LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(30,40,30,20);
  TextView t=new TextView(this); t.setText("🎱 Billiard Pocket Trainer V4"); t.setTextSize(25); l.addView(t);
  TextView d=new TextView(this); d.setText("\nاختار البوكت، والأداة تحسب مسار الـBank Shot حتى 3 ارتدادات ونقاط الارتداد.\nيمكنك تحريك الكرة ومقبض الاتجاه وتغيير حجم الطاولة."); d.setTextSize(16); l.addView(d);
  Button p=new Button(this); p.setText("صلاحية الظهور فوق التطبيقات"); l.addView(p);
  p.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))));
  Button s=new Button(this); s.setText("تشغيل الأداة"); l.addView(s);
  s.setOnClickListener(v->{if(Settings.canDrawOverlays(this)) startService(new Intent(this,OverlayService.class)); else Toast.makeText(this,"اسمح بالصلاحية أولاً",Toast.LENGTH_SHORT).show();});
  Button x=new Button(this); x.setText("إيقاف"); l.addView(x); x.setOnClickListener(v->stopService(new Intent(this,OverlayService.class)));
  setContentView(l);
 }
}